﻿namespace Entity
{
    public class UsuarioEntity
    {
        public string Nombre { get; set; }

        public string? Apellido { get; set; }

        public int Dni { get; set; }

        public string Contraseña { get; set; } 

        public string Usuario { get; set; }

        public bool Admin { get; set; }
    }
}
